<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
						<a href="index.php"><img src="images/47.png" alt="" /></a>
					</div>
			    <div class="call">
			    	<p><img src="images/45.png" alt="" />Call US: +91 9108886334</p>
			    </div>
			  			 
			<div class="clear"></div>
  		</div>
  	  </div>
	<div class="header_bottom">
		<div class="wrap">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>
					<li><a href="services.php">Services</a></li>			    	
			    	<li><a href="about.php">About Us</a></li>
			  
			    	
			    	<div class="clear"></div>
     			</ul>
	     	</div>
			<div class="social-icons">
	     		<ul>
	     			<!----------------login------>
	     		</ul>
	     	</div>
	     	<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div> 	     
	  </div>
	   <div class="main">
    <div class="content">
    
    	 <div class="wrap">
          
    	 	<div class="image group">
				
				<div class="grid span_2_of_3">
				
<div class="contact_info">
    	 				<h2>Find Us Here</h2>
					    	  <div class="map">
							  
							   	    <iframe width="100%" height="180" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#666;text-align:left;font-size:12px">View Larger Map</a></small>
							  </div>
      				</div>
      			<div class="company_address">
				     	<h2>Company Information :</h2>
						    	<p>LAKME SALON,</p>
						   		<p>SURVEY NO 61/3,HOTEL CENTRAL PARK BUILDING,SHIVALLI MANIPAL,</p>
						   		<p>INDIA</p>
				   		<p>Phone:(+91) 9108886334</p>
				   		<p>Fax: (000) 1784567898</p>
				 	 	<p>Email: <span>lakmeindia@gmail.com</span></p>
				   		<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				 </div>
			  </div>			
       </div>
    </div>
 </div>
</div>
				</div>
				</div>
				</div>
<div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">ABOUT US</a></li>
						     		<li><a href="#">PRIVACY POLICY</a></li>
						     		<li><a href="#">NEWSLETTER</a></li>
						     		<li><a href="#">SITE MAP</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
							<ul>
						  	 <li>LAKME SALON,</li>
						  	  <li>SURVEY NO 61/3,HOTEL CENTRAL PARK BUILDING,SHIVALLI MANIPAL,</li>
						  	   <li>INDIA.</li>
						  	 <li>lakmeindia@gmail.com</li>
						  	 <li><span>Phone :</span> +919108886334</li>
						  	 <li><span>Fax :</span> 0001748567898</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">ABOUT OUR COMPANY</a></li>
						     		<li><a href="#">TERMS &amp; CONDITIONS</a></li>
						     		<li><a href="#">NEWS</a></li>
						     		<li><a href="#">TEAM OF PROFESSIONALS</a></li>	
						     		<li><a href="#">TESTIMONIALS</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/28.png" alt=""><a href="#">JOIN US ON FACEBOOK</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">FOLLOW US ON TWITTER</a></li>
					     <li><img src="images/39.png" alt=""><a href="#">SHARE US ON TWITTER</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>	
	     
			<center><h1><b><font color="black"><i><pre></pre></b></center></h1></i></font><br><i><font size="3" color="brown">
<div class="copy_right">
				<p>LAKME SALON © All rights Reseverd  </a></p>
		 </div>
</body>
</html>


