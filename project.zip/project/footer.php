        
			   </div>
		   </div>
    	     
	      
				
			   </div>
		  </div>
      
 
				
	   <div class="clear"></div>
     </div>
    </div>
  </div>
  <div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">ABOUT US</a></li>
						     		<li><a href="#">PRIVACY POLICY</a></li>
						     		<li><a href="#">NEWSLETTER</a></li>
						     		<li><a href="#">SITE MAP</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
							<ul>
						  	 <li>LAKME SALON,</li>
						  	  <li>SURVEY NO 61/3,HOTEL CENTRAL PARK BUILDONG ,SHIVALLI MANIPAL,</li>
						  	   <li>INDIA</li>
						  	 <li>www.lakmeindia@gmail.com</li>
						  	 <li><span>Phone :</span> +91 9108886334</li>
						  	 <li><span>Fax :</span> 0001784567898</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">ABOUT OUR COMPANY</a></li>
						     		<li><a href="#">TERMS &amp; CONDITIONS</a></li>
						     		<li><a href="#">NEWS</a></li>
						     		<li><a href="#">TEAM OF PROFESSIONALS</a></li>	
						     		<li><a href="#">TESTIMONIALS</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/28.png" alt=""><a href="#">JOIN US ON FACEBOOK</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">FOLLOW US ON TWITTER</a></li>
					     <li><img src="images/39.png" alt=""><a href="#">SHARE US ON TWITTER</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
<div class="copy_right">
				<p>LAKME SALON © All rights Reseverd</a></p>
		 </div>
</body>
</html>

