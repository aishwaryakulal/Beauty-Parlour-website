﻿<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
						<a href="index.php"><img src="images/47.png" alt="" /></a>
					</div>
			    <div class="call">
			    	<p><img src="images/45.png" alt="" />Call US: +9108886334</p>
			    </div>
			  			 
			<div class="clear"></div>
  		</div>
  	  </div>
	<div class="header_bottom">
		<div class="wrap">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>	
					<li><a href="services.php">Services</a></li>					
			    	<li><a href="about.php">About Us</a></li>
			    	
			    	
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="social-icons">
	     		<ul>
	     			<!----------------login------>
	     		</ul>
	     	</div>
  	<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div> 
	     	
	 
    </div>  
       <div class="slider">
       	 <div class="wrap">
       	   <div class="slider_top">         
         		<div class="slider_left">
				  <div class="wmuSlider example2">
					<div class="wmuSliderWrapper">
					<article> <img src="images/5.jpg" alt="" height="350px" /> </article>
					<article> <img src="images/61.jpg" alt="" height="350px" /> </article>
					<article> <img src="images/4.jpg" alt="" height="350px" />  </article>
					<article> <img src="images/54.jpg" alt="" height="350px" />  </article>
					<article> <img src="images/banner1.jpg" alt="" height="350px" />  </article>
					<article> <img src="images/52.jpg" alt="" height="350px" />  </article>
					</div>	
					<script src="js/jquery.wmuSlider.js"></script> 
					<script type="text/javascript" src="js/modernizr.custom.min.js"></script> 
					<script> 
					        $('.example2').wmuSlider({
					            touch: true,
					            animation: 'slide'
					        });   
					        
				    </script> 			
				 </div>
				</div>				
				   <div class="slider_right">
				      <img src="images/9.jpg" alt="" height="350px" />
				    </div>
				<div class="clear"></div>			 
		   </div>
			 <div class="slider_bottom">
			   <div class="section group">
				
				
				
		    </div>
		  </div>
		</div> 
	 </div>
 <div class="main">
    <div class="content">
    	 <div class="wrap">
    	 	<div class="image group">
				
    	     	      
			<div class="spa_products">
				<h2>Latest Products</h2>
				<div class="section group">
				<div class="products_1_of_3">
					  <img src="images/62.jpg" alt="" />
					  <h3>Lakme 9TO5 Lipstick</h3>
					  <p>The Lakme 9to5 weightless mousse lipstick comes in a mousse texture that's weightless,giving a powdery matte finish to lips.It looks and feels weightless because of lightweight formula.TRY NOW!!!</p>
		
				</div>
				<div class="products_1_of_3">
					   <img src="images/63.jpg" alt="" />
					  <h3>Lakme Rose Face Powder, Soft Pink, 40g</h3>
					  <p>Bought to you from the house of Lakme Classics, The Lakme Rose Powder is a classic must-have. Blush your cheeks with this Lakme Rose Powder which has a light rosy fragrance & sunscreen to protect your soft, peachy skin. The Lakme Rose Powder comes in two warm pink shades which you can pick according to your skin type and occasion.GRAB IT NOW!!!</p>
				
				</div>
				<div class="products_1_of_3">
					   <img src="images/64.jpg" alt="" />
					  <h3>Lakme Makeup Kit</h3>
					  <p>So ladies,have you been looking for an inclusive makeup kit? if yes,then we have got you covered with makeup-kit that contain most makeup essentials at a relatively affordable price.CHOOSE THE BEST!!!</p>

				</div>
			   </div>
		  </div>
       </div>
    </div>
 </div>


		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
  <div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">About Us</a></li>
						     		<li><a href="#">Privacy Policy</a></li>
						     		<li><a href="#">Newsletter</a></li>
						     		<li><a href="#">Site Map</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
							<ul>
						  	 <li>LAKME SALON,</li>
						  	  <li>SURVEY NO 61/3,HOTEL CENTRAL PARK BUILDING,SHIVALLI MANIPAL,</li>
						  	   <li>INDIA</li>
						  	 <li>www.lakmeindia@gmail.com</li>
						  	 <li><span>Phone :</span> +9108886334</li>
						  	 <li><span>Fax :</span> 0001784567898</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">About our Company</a></li>
						     		<li><a href="#">Terms &amp; conditions</a></li>
						     		<li><a href="#">News</a></li>
						     		<li><a href="#">Team of professionals</a></li>	
						     		<li><a href="#">Testimonials</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/28.png" alt=""><a href="#">Join Us on Facebook</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">Follow Us on Twitter</a></li>
					     <li><img src="images/39.png" alt=""><a href="#">Share Us on Twitter</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
<div class="copy_right">
				<p>LAKME SALON © All rights Reseverd</a></p>
		 </div>
</body>
</html>

