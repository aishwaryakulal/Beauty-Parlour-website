<?php
include 'admin_header.php';
?>
				
				
 
    <ul id="contentUl">
    <div id="rightDiv">
        	<form action="brand_validation.php" method="post">
			<h1><font color="pink">ADD BRAND</h1></font>
            	<li><label><font color="white">Brand Name:</label><input type="text" name="txtBrandName" placeholder="Enter the Brand name..." required/></font></li>
                <li><input  type="submit" name="Save" value="Save"/></li>
                <a href="view_brand.php"><font color="green">View Brands</font></a>
</form>
   
    </ul>
    </div>
    </div>
	
    </body>
</html>

