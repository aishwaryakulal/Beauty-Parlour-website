<?php
    $con=mysqli_connect('localhost','root','','beauty_parlour');
?>
