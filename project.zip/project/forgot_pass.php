<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
						<a href="index.php"><img src="images/47.png" alt="" /></a>
					</div>
			    <div class="call">
			    	<p><img src="images/45.png" alt="" />Call US: +91 9108886334</p>
			    </div>
			  			 
			<div class="clear"></div>
  		</div>
  	  </div>
	<div class="header_bottom">
		<div class="wrap">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>
<li><a href="services.php">Services</a></li>			    	
			    	<li><a href="about.php">About Us</a></li>
			  
			    	
			    	<div class="clear"></div>
     			</ul>
	     	</div>
			<div class="social-icons">
	     		<ul>
	     			<!----------------login------>
	     		</ul>
	     	</div>
	     	<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div> 	     
	  </div>
	   <div class="main">
    <div class="content">
    
    	 <div class="wrap">
          
    	 	<div class="image group">
				
				<div class="grid span_2_of_3">