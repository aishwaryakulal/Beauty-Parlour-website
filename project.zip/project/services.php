<!DOCTYPE HTML>


<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
						<a href="index.php"><img src="images/47.png" alt="" /></a>
					</div>
			    <div class="call">
			    <p><img src="images/45.png" alt="" />Call US: +91 9108886334</p>
			    </div>
			  			 
			<div class="clear"></div>
  		</div>
  	  </div>
	<div class="header_bottom">
		<div class="wrap">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>	
<li><a href="services.php">Services</a></li>					
			    	<li><a href="about.php">About Us</a></li>
			    	
			    	
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="social-icons">
	     		<ul>
	     			<!----------------login------>
	     		</ul>
	     	</div>
	     	<div class="clear"></div>
	      </div>	     
	  </div>	


	
	     	<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div>  
 <div class="main">
    <div class="content">
    	 <div class="wrap">
    	 	<div class="services">
    	 		 <h2>Our Services</h2>
				<div class="section group">
				  <div class="col_1_of_4 span_1_of_4">
				  <img src="images/corporate-b.jpg" alt="" />
					<h3><span>Nail</span><br> Treatments</h3>
							<div class="services_list">
			          			<ul>
				                   <li><a href="">Nail Extension Removal	30 min	₹ 950</a></li>
				                    <li><a href="">Nail Extension French	30 min	₹ 3200</a></li>
				                    <li><a href="">Illuminate Nail Art	30 min	₹ 750</a></li>
				                    <li><a href="">Nail Extension Natural	40 min	₹ 350</a></li>
				                    <li><a href="">Style Gel Application	30 min	₹ 1200</a></li>
				                </ul>
			          		</div>
			  		   </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/It helps keep your skin supple.jpg" alt="" />
					<h3><span>Facial</span><br>Treatment</h3>
							<div class="services_list">
								<ul>
				                   <li><a href="">Berry Cleanup	45 min	₹ 1000</a></li>
				                    <li><a href="">Fruit Facial	45 min	₹ 1600</a></li>
				                    <li><a href="">Good Bye Tan Facial	45 min	₹ 1600</a></li>
				                    <li><a href="">Quick Glow Masque	45 min	₹ 750</a></li>
				                    <li><a href="">Sensi Calm Facial	45 min	₹ 1600</a></li>
									 <li><a href="">Choco Revival Facial	60 min	₹ 1100</a></li>
				                 <li><a href="">Gold Collagen Masque	60 min	₹ 2500</a></li>
				                </ul>
							</div>
					</div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/44.jpg" alt=""   style=" height: 150px; width: 200px; "/>
					<h3><span>Hair</span><br>Treatments</h3>
							<div class="services_list">
			          			<ul>
			          				<li><a href="">Hair Cut 10 min ₹  200</a></li>
				                    <li><a href="">Hair Smoothening 1 hr ₹  3500</a></li>
				                   <li><a href="">Hair Curling 1 hr ₹  4000</a></li>
				                    <li><a href="">Hair Rebonding 30 min ₹2000</a></li>	
				                     <li><a href="">Hair Shampooing 30 min ₹  500</a></li>	
									<li><a href="">Hair coloring	60 min	₹ 4300</a></li>
									<li><a href="">Hair straightening	1hr	₹ 9000</a></li>									 
				                </ul>
			          		</div>
						</div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/body-spa.png" alt="" style=" height: 150px; width: 200px;"/>
					<h3><span>Body</span><br>Spa</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Bak Massage Stress Relief 30 min	₹ 700</a></li>
				                    <li><a href="">Back Massage	Relaxing 30 min	₹ 700</a></li>
				                    <li><a href="">Marine Back Glow	30 min	₹ 1300</a></li>
				                    <li><a href="">Bleach Face And Neck 60 min	₹ 520</a></li>
				                    <li><a href="">Bleach Feet 30 min	₹ 240</a></li>
										
	
	


				                </ul>
							</div>
					</div>
	            </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/33.jpg" alt="" style=" height: 150px; width: 200px;" />
					<h3><span>Body</span><br>Treatments</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Argan Oil Wax -Body	90 min	₹ 2300</a></li>
				                    <li><a href="">Waxing -Midriff	15 min	₹ 350</a></li>
				                    <li><a href="">Waxing - Full Body	60 min	₹ 1400</a></li>
				                    <li><a href="">Peel Of Waxing -Neck	20 min	₹ 150</a></li>
				                </ul>
							</div>
					</div>
	            </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/gorgeous-brides-kandivali-east-mumbai-0b089.jpg" alt="" style=" height: 150px; width: 200px;" />
					<h3><span>Bridal</span><br>Makeup</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Mehendi ₹ 1500</a></li>
				                    <li><a href="">Wedding Makeup HD Airbrush Makeup ₹ 20000</a></li>
				                    <li><a href="">Specialised Saree Draping ₹ 775</a></li>
				                    <li><a href="">Blow Dry	₹ 575</a></li>
				                    <li><a href="">Hair Styling ₹ 5000</a></li>
				                </ul>
							</div>
					</div>
					<div class="col_1_of_4 span_1_of_4">
				<img src="images/61.jpg" alt="" style=" height: 150px; width: 200px; "/>
					<h3><span>Eye</span><br>Makeup</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Eye Rejuvenation ₹ 725</a></li>
				                    <li><a href="">Eye Rescue Treatment ₹ 1250</a></li>
				                    <li><a href="">Threading ₹50</a></li>
				                    <li><a href="">Glitter Eye Makeup	₹ 1400</a></li>
				                    <li><a href="">Shimmer Eye Makeup ₹ 1500</a></li>
				                </ul>
							</div>
					</div>
	            </div>
				
	            <div class="section group example">
				<div class="col_1_of_2 span_1_of_2">
				   <h3>Highlights</h3>
				   <p><span>AN ALLY TO THE CLASSIC INDIAN WOMEN, LAKME INSPIRES HER TO EXPRESS THE UNIQUE BEAUTY AND SENSUALITY WITHIN........ENABLING HER TO REALIZE THE POTENCY OF HER BEAUTY.</span></p>
 				       <h4><span>HAIR CARE</span>        -SHOP AND GET UPTO 40% OFF</h4>
 						<p>Get deep and intensive hydration with rich antioxidants and protien which have the ability to restore and renew the most porous and the damaged hair.</p>
 				    <h4><span>EYE MAKEUP</span>          -SHOP AND GET UPTO 20% OFF</h4>
 						<p>If you want to keep it low key and casual with only some soft,pink eyeshadow and mascara,then this brand is an ideal choice for work or when you are heading out for sunday brunch.</p>
 				    <h4><span>BRIDAL MAKEUP</span>       -GET UPTO 50% OFF</h4>
 						<p>Your bidal makeup is a last lap to your dream wedding look and the one that plays a major role in bringing it all together.Luckily,you have come to the right place..... </p>
 				       <h4><span>SPA TREATMENT</span>    -GET UPTO 40% OFF</h4>
 						<p>Facial skin isn't the only area that needs exfoliation and moisturizing.Spas proide a variety of skin treatments for the entire body.</p>
 				      <h4><span>NAIL TREATMENT</span>    -GET UPTO 10% OFF</h4>
 						<p>Paint it on yourself or hit up your manicure spot for a pristine application.Just make sure you spend ample time under the nail dryer or you'll risk those dreaded dings on the way out.</p>
 				</div>
				<div class="col_1_of_2 span_1_of_2">
				   <h3>Treatments</h3>
				   <div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/bridal-makeup.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>HAIR TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/eye-makeup.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>EYE MAKEUP</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/highlighting-hair.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>BRIDAL MAKEUP</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/pedicure.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>SKIN TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/spa.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>SPA TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/manicure.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>NAIL TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
				</div>
		    </div>
     		 </div>
    		</div>
	    </div>
    </div>
 <div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">ABOUT US</a></li>
						     		<li><a href="#">PRIVACY POLICY</a></li>
						     		<li><a href="#">NEWSLETTER</a></li>
						     		<li><a href="#">SITE MAP</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
								<ul>
						  	 <li>LAKME SALON,</li>
						  	  <li>SURVEY NO 61/3,HOTEL CENTRAL PARK BUILDING,SHIVALLI MANIPAL,</li>
						  	   <li>INDIA.</li>
						  	 <li>www.lakmeindia@gmail.com</li>
						  	 <li><span>Phone :</span> +91 9108886334</li>
						  	 <li><span>Fax :</span> 0001784567898</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">ABOUT OUR COMPANY</a></li>
						     		<li><a href="#">TERMS &amp; CONDITIONS</a></li>
						     		<li><a href="#">NEWS</a></li>
						     		<li><a href="#">TEAM OF PROFESSIONALS</a></li>	
						     		<li><a href="#">TESTIMONIALS</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/28.png" alt=""><a href="#">Join Us on Facebook</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">Follow Us on Twitter</a></li>
					     <li><img src="images/39.png" alt=""><a href="#">Share Us on Twitter</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
<div class="copy_right">
				<p>LAKME SALON © All rights Reseverd </a></p>
		 </div>
</body>
</html>

