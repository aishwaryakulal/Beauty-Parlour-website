<?php
include "customer_header.php";
?>
<html>
<head>
    <br>
    <td><center><font color="white"><b><?php echo "Your order is placed,THANK YOU";?></td>
    <br><a href="customer_item_select.php?>"><img src="images/fleche.png" width="24px" style="    padding-left: 363px;">Back</a>
</body>
</html> 

		 
         
<?php 
include "footer.php";
?>